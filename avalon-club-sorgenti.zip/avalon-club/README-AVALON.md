# Avalon — Il club dei bugiardi

Sito multiplayer per otto persone, con l’identità visiva avorio, nero e rosso e otto personaggi originali illustrati. Ogni giocatore entra dal proprio dispositivo. La versione Sites usa ChatGPT; il server temporaneo usa una sessione ospite privata per ogni browser.

## Stato della consegna

L’applicazione e il database sono implementati e verificati localmente. La pubblicazione su Sites non è stata completata: il canale interattivo richiesto dalla sincronizzazione del repository è stato rifiutato dal controllo automatico delle autorizzazioni. Non esiste ancora un indirizzo pubblico funzionante. Il progetto Sites è già registrato in `.openai/hosting.json`: riusare lo stesso ID, senza creare un secondo sito.

## Funzioni

- Creazione di stanze con codice da sei caratteri, ingresso, riconnessione e stato di disponibilità.
- Partita per esattamente otto persone: cinque buoni e tre cattivi.
- Merlino vede Morgana e Assassino come cattivi, ma non Mordred.
- Parsifal vede due nomi, Merlino e Morgana, senza distinguerli.
- Morgana, Mordred e Assassino conoscono i complici.
- Quercia, Raggio e Prisma sono buoni generici senza informazioni aggiuntive.
- Voti coperti fino all’ottava risposta; maggioranza di cinque, parità come rifiuto.
- Squadre di 3, 4, 4, 5 e 5 persone. La quarta missione richiede due sabotaggi.
- Tre fallimenti oppure cinque proposte consecutive rifiutate danno la vittoria ai cattivi.
- Dopo tre successi l’Assassino ha una sola scelta per identificare Merlino.
- Chat pubblica, verbale dei voti e rivincita nella stessa stanza.

La visuale del tavolo è personale e filtrata dal server. Nella sala di attesa tutti hanno la sagoma con il punto interrogativo. Dopo l’inizio ogni giocatore vede il proprio personaggio; Merlino vede Morgana e Assassino ma non Mordred; i cattivi vedono i complici; Parsifal vede Merlino e Morgana con la stessa immagine composita, senza distinguerli. I tre leali vedono soltanto il proprio personaggio. Tutti gli altri restano sconosciuti. A fine partita si rivelano tutte le identità. Il pulsante Home riporta all’ingresso senza annullare la stanza e conserva il codice per rientrare.

## Verifica

Sono passati dieci test del motore di gioco, inclusa la matrice completa dei ritratti consentiti a ciascun ruolo, e un test d’integrazione con otto identità simulate, richieste concorrenti, persistenza D1, voti simultanei, esito di missione e isolamento degli accessi. Verificati anche compilazione TypeScript, build di produzione e flusso browser (creazione, riconnessione, scheda privata, Home, larghezza mobile 390 px senza overflow).

L’integrazione si esegue contro un’istanza locale del Worker di produzione con identità di prova; non deve essere eseguita contro un sito ospitato.

## Sviluppo

### Link temporaneo Cloudflare

Su questo computer, aprire `Avvia-Avalon.cmd` nella cartella `outputs` con doppio clic. Il programma Cloudflare ufficiale 2026.10.0 è già scaricato e il suo SHA256 è stato verificato. L’avvio automatico da questa sessione è stato bloccato dal controllo delle autorizzazioni: il collegamento pubblico non è stato ancora attivato. Il file avvia esplicitamente un tunnel pubblico per il solo gioco; mostra il link da condividere nella finestra che si apre. Chiudere la finestra interrompe il tunnel. Per usare i soli sorgenti su un altro computer, installare Cloudflare e impostare `CLOUDFLARED_PATH` al suo eseguibile, oppure avviarlo manualmente come descritto sotto.

Dopo la build, avviare `node scripts/temporary-host.mjs`, poi `cloudflared tunnel --url http://127.0.0.1:8788`. Condividere l’indirizzo HTTPS stampato da Cloudflare. Richiede che computer, server e tunnel restino attivi. Il link cambia a ogni nuovo tunnel. Entrare scegliendo un nome, creare una stanza e condividere il suo codice con gli altri sette partecipanti.

Il server espone solo la build compilata e le API del gioco. Non esporre il server di sviluppo sulla porta 5173 né il Worker di prova direttamente. I cookie ospite sono firmati, HttpOnly e Secure sul link pubblico; tutti gli header di identità ricevuti dall’esterno sono scartati. L’accesso ospite è abilitato soltanto nel Worker locale avviato da questo script. La configurazione e l’audience Sites restano indipendenti. Cookie e stanze durano al massimo 48 ore; usando un altro browser si entra come un nuovo giocatore.

Database e chiave di sessione del server temporaneo rimangono in `.sites-runtime/temporary-host`, esclusi dall’archivio dei sorgenti. Verifica locale: `node tests/temporary-host.test.mjs` (crea una stanza di prova con otto ospiti). Controlla file pubblici, sessioni distinte, visioni Merlino/Parsifal, firme dei cookie, origini delle richieste e indisponibilità dei file interni.

### Tavolo

Le otto sedute seguono il perimetro del tavolo con posizioni adattate al telefono. Tutti i ritratti e i nomi sono davanti al piano del tavolo: nessun personaggio viene coperto dal bordo. Nomi e stato del giocatore sono sotto il ritratto. Le figure sconosciute e la visione di Parsifal hanno proporzioni dedicate.

La base è il template Vinext di Sites con React e D1. Usare la procedura Sites per installazione, build e pubblicazione. Per lo sviluppo ordinario: `npm ci`, `npm run dev`; per la build: `npm run build`; test delle regole: `node --test tests/game.test.mjs`.

Applicare `drizzle/0000_yummy_retro_girl.sql` al database locale prima di provare le stanze. La pubblicazione Sites applicherà separatamente la migrazione ospitata. I dati locali di prova e `.sites-runtime` non fanno parte dei sorgenti da pubblicare.

Prima di consentire l’ingresso agli amici, scegliere l’accesso del sito: Sites lo registra privato. Non è stata cambiata l’audience. Le stanze scadono dopo 48 ore senza azioni. L’aggiornamento dello stato avviene circa ogni 2,2 secondi. La chat è testuale; la voce può essere gestita con una chiamata esterna.

## Asset

`public/assets/characters.png`: tavola originale 4×2, generata con ImageGen, 1448×1086. Prima riga: Merlino, Morgana, Parsifal, Mordred. Seconda riga: Assassino, Quercia, Raggio, Prisma. Lo stile richiesto è una stampa incisa avorio, nero e rosso con maschere teatrali e abiti eleganti. Nessuna credenziale è inclusa nei file.

Regolamento di riferimento: https://www.rulespal.com/resistance-avalon/rulebook

Rifinitura asset: `public/assets/characters-cutouts.png` contiene gli stessi otto personaggi con sfondo trasparente, ottenuto con ImageGen preservando le zone avorio interne a maschere, mani e camicie. È l’asset usato nell’interfaccia; la prima versione è conservata come riferimento.

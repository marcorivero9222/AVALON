import {readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const source=await readFile(path.join(root,'lib/catalogue.ts'),'utf8');
const roles=[...source.matchAll(/\{id:'([^']*)',name:'([^']*)',side:'([^']*)',art:(\d+),mask:'([^']*)',description:'([^']*)'\}/g)].map(([,id,name,side,art,mask,description])=>({id,name,side,art:Number(art),mask,description}));
if(roles.length!==8)throw new Error('Expected eight roles');
const club=await readFile(path.join(root,'app/club.tsx'),'utf8');
const positions=JSON.parse(club.match(/const positions=(\[.*?\]);/)[1]);
let css=(await readFile(path.join(root,'app/globals.css'),'utf8'))+'\n'+(await readFile(path.join(root,'app/table.css'),'utf8'));
css=css.replace("background-image:url('/assets/characters.png')","background-image:none");
for(const file of ['characters-cutouts.png','unknown-player.png','parsifal-vision.png']){
  const data=(await readFile(path.join(root,'public/assets',file))).toString('base64');
  css=css.replaceAll('/assets/'+file,'data:image/png;base64,'+data);
}
const html=`<!doctype html>
<html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Avalon — Il club dei bugiardi</title><style>${css}
[hidden]{display:none!important}.preview-note{font:10px var(--mono);padding:10px 0;border-bottom:1px solid var(--line);color:var(--muted)}.demo-controls{display:flex;gap:16px;align-items:center;flex-wrap:wrap;padding:18px 0;border-bottom:1px solid var(--line)}.demo-controls label{font:11px var(--mono)}.demo-controls select{font:14px var(--body);padding:10px;background:var(--paper);color:var(--ink);border:1px solid var(--ink);max-width:100%;min-height:44px}.demo-description{font-size:13px;max-width:540px;color:var(--muted)}.table-stage .seat.own .name-tag{border:2px solid var(--red)}.preview-dialog{max-width:620px}.preview-dialog p{line-height:1.7;margin:16px 0}.preview-dialog h2{font:700 48px/1 var(--display)}.preview-dialog .portrait{width:180px;margin:0 auto 20px}.preview-dialog .portrait-unknown,.preview-dialog .portrait-parsifal{display:none}
</style></head><body><main>
<header class="masthead"><a href="#" class="wordmark" id="brand">AVALON<span>✦</span></a><span class="club-name">IL CLUB DEI BUGIARDI</span><nav><button id="home" class="home-button" hidden>← Home</button><button id="rules">Come si gioca ↗</button></nav></header>
<p class="preview-note">ANTEPRIMA INTERATTIVA · Per giocare online usa la versione Docker.</p>
<section class="hero" id="hero"><div class="hero-copy"><div class="eyebrow"><span class="red-dot"></span>UN GIOCO DI FIDUCIA. O QUASI.</div><h1>QUI NESSUNO<br>È <em>INNOCENTE.</em></h1><p>Otto maschere. Cinque leali. Tre traditori.<br>Siediti al tavolo. Scegli di chi fidarti.</p><div class="hero-meta"><span>08 GIOCATORI</span><span>30–45 MIN</span><span>AVALON</span></div></div>
<form class="entry-card" id="entry"><div class="entry-heading"><span class="eyebrow">IL TUO POSTO AL TAVOLO</span><span>↙</span></div><label for="name">COME TI CHIAMI?<input id="name" placeholder="Il nome con cui mentirai" maxlength="22" autocomplete="nickname" required></label><button class="primary">ESPLORA IL TAVOLO <span>↗</span></button><p class="entry-note">Prova le maschere e le informazioni dei ruoli.<br>Questa anteprima non crea stanze online.</p></form></section>
<section id="demo" hidden><div class="room-line"><span><i class="status-dot"></i> AL TAVOLO</span><span>PARTITA DIMOSTRATIVA · 8 PERSONAGGI</span></div><div class="game-heading"><div><span class="eyebrow">OTTO IDENTITÀ. NESSUNA CERTEZZA.</span><h1>DI CHI<br>TI FIDI?</h1></div><div class="quest-tracker"><div class="quests">${[3,4,4,5,5].map((n,i)=>`<div><span>0${i+1}</span><div class="quest ${i===0?'current':''}">${n}</div><small>${n} PERSONE</small></div>`).join('')}</div><p>CINQUE MISSIONI · DUE FAZIONI</p><small>Quarta missione: servono 2 sabotaggi.</small></div></div><div class="demo-controls"><label for="vision">LA TUA VISUALE</label><select id="vision"><option value="lobby">Prima della partita</option>${roles.map(r=>`<option value="${r.id}">${r.name}</option>`).join('')}<option value="all">Fine partita · Tutte le identità</option></select><p id="description" class="demo-description" aria-live="polite"></p></div></section>
<section class="showcase"><div class="section-label"><span>IL CLUB DEI BUGIARDI</span><span id="table-hint">ESPLORA LE MASCHERE ↓</span></div><div id="table" class="table-stage exhibition" aria-label="Otto personaggi intorno al tavolo"></div><div class="showcase-caption"><span>LA SOCIETÀ AL COMPLETO</span><p>Al tavolo vedi il tuo personaggio<br>e soltanto ciò che il tuo ruolo ti rivela.</p><span class="caption-star">✦</span></div></section>
<section class="how-strip"><article><span>01 / OSSERVA</span><h2>Tutti hanno<br>qualcosa da nascondere.</h2><p>Ricevi una maschera e le informazioni che soltanto il tuo ruolo può conoscere.</p></article><article><span>02 / SCEGLI</span><h2>La fiducia<br>si mette ai voti.</h2><p>Proponi una squadra, discuti al tavolo e vota. Ogni scelta lascia una traccia.</p></article><article><span>03 / SOPRAVVIVI</span><h2>Anche vincere<br>può essere una trappola.</h2><p>Tre missioni riuscite non bastano: Merlino deve sfuggire all’ultimo colpo.</p></article></section>
<footer class="site-footer"><span>AVALON <b>✦</b> IL CLUB DEI BUGIARDI</span><span>LA FIDUCIA È UNA SCELTA.</span><span>ANTEPRIMA HTML</span></footer>
<dialog id="detail" class="preview-dialog"><div class="dialog-header"><span class="eyebrow">IL SEGRETO DELLA MASCHERA</span><button id="close" class="icon-button" aria-label="Chiudi">×</button></div><div id="detail-content"></div></dialog>
<noscript><p>Abilita JavaScript per vedere i personaggi e provare le visuali dei ruoli.</p></noscript>
</main><script>
const roles=${JSON.stringify(roles)}, positions=${JSON.stringify(positions)};
const $=id=>document.getElementById(id), names=['Nora','Luca','Mia','Elia','Sofia','Leo','Ada','Teo'];
let playing=false, playerName='Tu';
function portrait(appearance){const node=document.createElement('div');node.className='portrait';node.setAttribute('aria-hidden','true');const role=roles.find(r=>r.id===appearance);if(role)node.style.backgroundPosition=(role.art%4)*100/3+'% '+(role.art<4?0:100)+'%';else node.classList.add(appearance==='pair'?'portrait-parsifal':'portrait-unknown');return node;}
function appearanceFor(role,viewer){
 if(!playing||viewer==='all')return role.id;
 if(viewer==='lobby')return 'unknown';
 if(role.id===viewer)return role.id;
 if(viewer==='merlin'&&role.side==='evil'&&role.id!=='mordred')return role.id;
 if(viewer==='percival'&&['merlin','morgana'].includes(role.id))return 'pair';
 if(roles.find(r=>r.id===viewer)?.side==='evil'&&role.side==='evil')return role.id;
 return 'unknown';
}
function openDetail(appearance){
 const content=$('detail-content');content.replaceChildren();const role=roles.find(r=>r.id===appearance);
 if(role)content.append(portrait(role.id));
 const title=document.createElement('h2');title.textContent=role?.name||(appearance==='pair'?'Merlino oppure Morgana':'Identità sconosciuta');content.append(title);
 const p=document.createElement('p');p.textContent=role?.description||(appearance==='pair'?'Una di queste due persone è Merlino, l’altra è Morgana. Parsifal vede la stessa immagine per entrambe e non può distinguerle.':'Questa persona resta nascosta. Il tuo ruolo non ti rivela la sua identità.');content.append(p);$('detail').showModal();
}
function render(){
 const viewer=$('vision').value, table=$('table');table.classList.toggle('exhibition',!playing);table.replaceChildren();
 const oval=document.createElement('div');oval.className='oval-table';
 oval.innerHTML=playing?'<div class="table-center"><span class="eyebrow">'+(viewer==='lobby'?'IL TAVOLO TI ASPETTA':viewer==='all'?'SIPARIO':'IL TUO SEGRETO')+'</span><strong>'+(viewer==='lobby'?'8 / 8':'✦')+'</strong><small>'+(viewer==='lobby'?'Identità ancora nascoste':viewer==='all'?'Tutte le maschere rivelate':'Solo ciò che puoi sapere')+'</small></div>':'<div class="table-engraving"><span class="star">✦</span><span>IL CLUB DEI BUGIARDI</span></div>';table.append(oval);
 roles.forEach((role,i)=>{const appearance=appearanceFor(role,viewer), own=playing&&viewer===role.id, seat=document.createElement('button');seat.type='button';seat.className='seat seat-'+i+(own?' own':'');seat.style.setProperty('--x',positions[i][0]+'%');seat.style.setProperty('--y',positions[i][1]+'%');const chair=document.createElement('span');chair.className='chair';seat.append(chair,portrait(appearance));const label=document.createElement('span');label.className='name-tag';label.textContent=playing?own?playerName+' · TU':names[i]:role.name;seat.append(label);if(playing){const tag=document.createElement('span');tag.className='seat-tag';tag.textContent=viewer==='lobby'?'IN ATTESA':own?'IL TUO RUOLO':appearance==='pair'?'DUE POSSIBILITÀ':appearance==='unknown'?'IDENTITÀ NASCOSTA':role.side==='evil'?'CATTIVO':'BUONO';seat.append(tag);}seat.setAttribute('aria-label',label.textContent+', '+(appearance==='unknown'?'identità sconosciuta':appearance==='pair'?'Merlino oppure Morgana':role.name));seat.addEventListener('click',()=>openDetail(appearance));table.append(seat);});
 $('description').textContent=viewer==='lobby'?'Prima dell’inizio tutti hanno il punto interrogativo.':viewer==='all'?'Alla fine della partita si rivelano tutte le identità.':roles.find(r=>r.id===viewer).description;
}
function showHome(){playing=false;$('hero').hidden=false;$('demo').hidden=true;$('home').hidden=true;$('table-hint').textContent='ESPLORA LE MASCHERE ↓';render();}
$('entry').addEventListener('submit',event=>{event.preventDefault();playerName=$('name').value.trim()||'Tu';playing=true;$('vision').value='lobby';$('hero').hidden=true;$('demo').hidden=false;$('home').hidden=false;$('table-hint').textContent='TOCCA UNA MASCHERA';render();});
$('home').addEventListener('click',showHome);$('brand').addEventListener('click',event=>{event.preventDefault();showHome();});$('vision').addEventListener('change',render);$('close').addEventListener('click',()=>$('detail').close());$('detail').addEventListener('click',event=>{if(event.target===$('detail'))$('detail').close();});
$('rules').addEventListener('click',()=>{$('detail-content').innerHTML='<h2>Otto persone.<br>Due fazioni.</h2><p>Cinque leali e tre traditori. Ogni turno il leader propone una squadra: 3, 4, 4, 5 e 5 persone nelle cinque missioni. Servono almeno cinque voti per approvarla.</p><p>I membri della squadra giocano una carta segreta. Solo i cattivi possono sabotare. Basta un sabotaggio per fallire, tranne nella quarta missione, dove ne servono due.</p><p>Tre fallimenti o cinque squadre consecutive rifiutate danno la vittoria ai cattivi. Dopo tre successi l’Assassino cerca Merlino: se lo trova, vincono comunque i cattivi.</p><p>Questa è una dimostrazione delle visuali. Per una partita tra dispositivi diversi avvia la versione Docker.</p>';$('detail').showModal();});render();
</script></body></html>`;
const destination=path.resolve(process.argv[2]||path.join(root,'../avalon.html'));
await writeFile(destination,html);
console.log('HTML exported:',destination);

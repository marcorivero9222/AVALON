import {spawn} from 'node:child_process';
import {access} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const binary=process.env.CLOUDFLARED_PATH||path.resolve(project,'../../work/cloudflare/cloudflared.exe');
await access(binary);
async function ready(){try{const r=await fetch('http://127.0.0.1:8788',{signal:AbortSignal.timeout(1500)});return r.ok&&(await r.text()).includes('Accesso ospite');}catch{return false;}}
console.log('\nAVALON - LINK TEMPORANEO\n');
console.log('Chi riceve il link potra aprire il gioco e creare o raggiungere una stanza.');
console.log('Tieni questa finestra aperta e il computer acceso durante la partita.\n');
let host;
if(!await ready()){
  host=spawn(process.execPath,['scripts/temporary-host.mjs'],{cwd:project,stdio:['ignore','inherit','inherit'],windowsHide:true});
  for(let attempt=0;attempt<30&&!await ready();attempt++)await new Promise(resolve=>setTimeout(resolve,500));
  if(!await ready()){host.kill();throw new Error('Il gioco non si e avviato sulla porta 8788.');}
}
console.log('Condividi l indirizzo https://...trycloudflare.com che comparira qui sotto.\n');
const tunnel=spawn(binary,['tunnel','--no-autoupdate','--url','http://127.0.0.1:8788'],{cwd:project,stdio:'inherit',windowsHide:true});
tunnel.on('error',error=>{console.error('Avvio Cloudflare non riuscito:',error.message);host?.kill();process.exitCode=1;});
tunnel.on('exit',code=>{host?.kill();process.exitCode=code||0;});
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{tunnel.kill();host?.kill();});
